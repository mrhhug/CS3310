﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ShoppingCartV2.Models;
using System.Net.Mail;

namespace ShoppingCartV2.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        // Text for Site Heading
        string siteHeading = "The Fun Cake Store";

        // Text for View Heading for each Tab
        string[] tabHeadings = { "Home", "Single Layer Cake", "Double Layer Cake", "Triple Layer Cake", "About US" };

        // View method name for each Tab
        string[] tabViews = { "Index", "Tab1Orders", "Tab2Orders", "Tab3Orders", "About" };

        // View label displayed on each Tab
        string[] tabLabels = { "Home", "1-Layer", "2-Layer", "3-Layer", "About" };

        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

                // Action Method for First Product View
        public ActionResult Tab1Orders()
        {
            Session["ProductType"] = tabViews[1];
            ViewData["Message"] = Session["Message"] = tabHeadings[1] + " Orders:";
            return View(loadViewTableData(Session["ProductType"].ToString(),1));
        }

        // Action Method for First Product View
        [HttpPost]
        public ActionResult Tab1Orders(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, loadViewTableData(pType,1));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[2]);  // This is the View for the next product page
            }
        }

        // Action Method for Second Product View
        public ActionResult Tab2Orders()
        {
            Session["ProductType"] = tabViews[2];
            ViewData["Message"] = Session["Message"] = tabHeadings[2] + " Orders:";
            return View(loadViewTableData(Session["ProductType"].ToString(),2));
        }

        // Action Method for Second Product View
        [HttpPost]
        public ActionResult Tab2Orders(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, loadViewTableData(pType,2));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[3]);  // This is the View for the next product page
            }
        }

        // Action Method for Second Product View
        public ActionResult Tab3Orders()
        {
            Session["ProductType"] = tabViews[3];
            ViewData["Message"] = Session["Message"] = tabHeadings[3] + " Orders:";
            return View(loadViewTableData(Session["ProductType"].ToString(), 3));
        }

        // Action Method for Second Product View
        [HttpPost]
        public ActionResult Tab3Orders(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, loadViewTableData(pType, 3));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[4]);  // This is the View for the next product page
            }
        }

        // Gets the list of tabs and the Site heading label
        public ActionResult GetTabs()
        {
            string tabStr = "<h1>" + siteHeading + "</h1>:<ul id=\"menu\">" + Environment.NewLine;
            for (int i = 0; i < tabViews.Length; ++i)
                tabStr += "<li><a href=\"/Home/" + tabViews[i] + "\">" +
                    tabLabels[i] + "</a></li>" + Environment.NewLine;
            tabStr += "</ul>";

            return Content(tabStr);
        }

        // Loads the submission details into session variables for each tab
        public void LoadSubmission(string name, int amount, FormCollection collection)
        {
            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value))
                    continue;
                Session[String.Format("{0}Amount{1}", name, i)] = collection[i - 1];
                Session[String.Format("{0}Price{1}", name, i)] =
                    Double.Parse(Session[String.Format("{0}UnitPrice{1}",
                      name, i)].ToString()) * value;
            }
        }

        // Converts table entries for a particular product type into a list of products for the website
        private List<Product> loadViewTableData(string pType, int viewIndex)
        {
            using (ShoppingCartDBEntities1 db1 = new ShoppingCartDBEntities1())
            {
                var productItems = from wp in db1.Products where (wp.ProductType == pType) select wp;
                int index = 1;
                foreach (var p in productItems)
                {
                    string pathlabel = "";
                    Session[pType + "ProductName" + index] = "";
                    if (String.IsNullOrWhiteSpace(p.ProductName) && String.IsNullOrWhiteSpace(p.ImageFile))
                        pathlabel = "[No Image]";
                    else
                    {
                        if (!String.IsNullOrWhiteSpace(p.ProductName))
                        {
                            pathlabel = p.ProductName.Trim();
                            Session[pType + "ProductName" + index] = pathlabel;
                            if (!String.IsNullOrWhiteSpace(p.ImageFile))
                                pathlabel += ":<br />";
                        }
                        if (!String.IsNullOrWhiteSpace(p.ImageFile))
                            pathlabel += "<img src=\"/Content/" + p.ImageFile.Trim() + "\" alt=\"Store Product Image\" />";
                    }
                    Session[pType + "Path" + index] = pathlabel;
                    Session[pType + "UnitPrice" + index] = p.UnitPrice;
                    if (Session[pType + "Amount" + index] == null)
                        ViewData["DefaultChoice" + index] = (p.DefaultAmount >= 0) ? p.DefaultAmount : 0;
                    else
                        ViewData["DefaultChoice" + index] = Int32.Parse(Session[pType + "Amount" + index].ToString());
                    ++index;
                }
                Session[pType + "ItemAmount"] = productItems.Count();
                return productItems.ToList();
            }
        }
    }
}
