﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingCartV2.Models;


namespace ShoppingCartV2.Controllers
{
    [HandleError]
    public partial class HomeController : Controller
    {
        // Text for Site Heading
        string siteHeading = "Farmer, Hug, Sullivan, Sweeting";

        // Text for View Heading for each Tab
        string[] tabHeadings = { "Home",
                                   "TVs", "Laptops", "Consoles", "Networking",
                                         "Check-Out", "Admin", "About" };

        // View label displayed on each Tab
        string[] tabLabels = { "Home",
                                   "TVs", "Laptops", "Consoles", "Networking",
                                         "Check-Out", "Admin", "About" };

        // View method name for each Tab
        string[] tabViews = { "Index",
                                   "TVs", "Laptops", "Consoles", "Networking",
                                         "CheckOut", "Admin", "About" };

        // Text for View Heading of any Options columns
        string[] optionsColumnHeading = { "",
                                   "TVs", "Laptops", "Consoles", "Networking",
                                         "Check-Out", "Admin", "About" };

        // The tax rate is 7%
        decimal taxRate = 0.07M;

        // Email address of the company that will be in the "From" box
        //  of the confirmation message sent
        string websiteEmail = "jim@illgiveyouafuncake.de";


        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to the electronics Store!";
            ViewData["Message"] += "<br /><img src=/Content/logo.jpg>";
            ViewData["Message"] += "<br />This is the electronics Store of your nightmare!";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        // Action Method for First Product View
        public ActionResult TVs()
        {
            Session["ProductType"] = tabViews[1];
            ViewData["Message"] = Session["Message"] = tabHeadings[1] + " Orders:";
            return View(LoadViewTableData(Session["ProductType"].ToString(),1));
        }

        // Action Method for First Product View
        [HttpPost]
        public ActionResult TVs(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            int tabNum = 1;
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, LoadViewTableData(pType, tabNum));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[tabNum+1]);  // This is the View for the next product page
            }
        }
        // Action Method for Second Product View
        public ActionResult Laptops()
        {
            Session["ProductType"] = tabViews[2];
            ViewData["Message"] = Session["Message"] = tabHeadings[2] + " Orders:";
            return View(LoadViewTableData(Session["ProductType"].ToString(), 2));
        }

        // Action Method for Second Product View
        [HttpPost]
        public ActionResult Laptops(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            int tabNum = 2;
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, LoadViewTableData(pType, tabNum));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[tabNum + 1]);  // This is the View for the next product page
            }
        }
        // Action Method for Third Product View
        public ActionResult Consoles()
        {
            Session["ProductType"] = tabViews[3];
            ViewData["Message"] = Session["Message"] = tabHeadings[3] + " Orders:";
            return View(LoadViewTableData(Session["ProductType"].ToString(), 3));
        }

        // Action Method for Third Product View
        [HttpPost]
        public ActionResult Consoles(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            int tabNum = 3;
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, LoadViewTableData(pType, tabNum));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[tabNum + 1]);  // This is the View for the next product page
            }
        }
        // Action Method for Fourth Product View
        public ActionResult Networking()
        {
            Session["ProductType"] = tabViews[4];
            ViewData["Message"] = Session["Message"] = tabHeadings[4] + " Orders:";
            return View(LoadViewTableData(Session["ProductType"].ToString(), 4));
        }

        // Action Method for Fourth Product View
        [HttpPost]
        public ActionResult Networking(string button, FormCollection collection)
        {
            string pType = Session["ProductType"].ToString();
            int amount = Int32.Parse(Session[pType + "ItemAmount"].ToString());
            int tabNum = 4;
            LoadSubmission(pType, amount, collection);

            for (int i = 1; i <= amount; i++)
            {
                int value;
                if (!Int32.TryParse(collection[i - 1], out value) || value < 0)
                {
                    ViewData.ModelState.AddModelError("", "Error: You put an invalid amount in Item #" + i);
                    ViewData["Message"] = Session["Message"];
                    return View(pType, LoadViewTableData(pType, tabNum));
                }
            }

            if (button == "Save And Go To Checkout")
            {
                return RedirectToAction("CheckOut");
            }
            else
            {
                return RedirectToAction(tabViews[tabNum + 1]);  // This is the View for the next product page
            }
        }
    }
}
